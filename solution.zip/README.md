# Acropolis Data Query Solution

This repository provides solutions to a data query problem using SQL and Python.

## Problem

Find the highest salary (not paid on the 1st day of any month), along with:
- Employee's full name
- Age at the time of payment
- Department name

## Files

- `solution.sql`: SQL query
- `solution.py`: Python (pandas) script

## Run Python

```bash
pip install pandas
python solution.py
```
